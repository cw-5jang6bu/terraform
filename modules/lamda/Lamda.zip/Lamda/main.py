import redis
import os

def lambda_handler(event, context):
    redis_host = os.getenv("REDIS_HOST", "your-redis-endpoint")
    redis_port = int(os.getenv("REDIS_PORT", 6379))

    try:
        client = redis.StrictRedis(host=redis_host, port=redis_port, decode_responses=True)
        return {"status": "success", "message": client.ping()}
    except Exception as e:
        return {"status": "error", "message": str(e)}

